
export default interface EditMode {
  productId: number | string,
  selectedOptions: Record<string, any>,
  qty: number
}

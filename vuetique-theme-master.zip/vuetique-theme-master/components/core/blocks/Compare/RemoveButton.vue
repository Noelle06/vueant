<template>
  <button
    class="border-0 bg-transparent p-4"
    :aria-label="$t('Remove')"
    :title="$t('Remove')"
  >
    <svg viewBox="0 0 25 25" class="vt-icon--sm">
      <use xlink:href="#close"/>
    </svg>
  </button>
</template>

<template>
  <button
    class="border-0 bg-grey-dark text-xs text-white uppercase font-medium py-1 px-2 inline-flex"
    data-testid="applyButton"
  >
    {{ $t('Apply') }}
  </button>
</template>

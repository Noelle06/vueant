import './style/index.less'

import InputNumber from './input-number'

export default InputNumber

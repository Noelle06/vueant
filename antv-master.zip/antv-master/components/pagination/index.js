import './style/index.less'

import Pagination from './pagination'

export default Pagination

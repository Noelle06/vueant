import Select from './select'
import Option from './option'
import OptionGroup from './option-group'

Select.Option = Option
Select.OptionGroup = OptionGroup

export default Select

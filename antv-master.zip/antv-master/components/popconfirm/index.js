import Popconfirm from './popconfirm'

export default Popconfirm

import Collapse from './collapse'
import Panel from './panel'

Collapse.Panel = Panel

export default Collapse

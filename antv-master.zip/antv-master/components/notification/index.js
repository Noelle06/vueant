import './style/index.less'

import Message from './notification'

export default Message

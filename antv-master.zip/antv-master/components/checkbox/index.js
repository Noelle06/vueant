import './style/index.less'

import Checkbox from './checkbox'
import CheckboxGroup from './checkbox-group'

Checkbox.Group = CheckboxGroup
export default Checkbox

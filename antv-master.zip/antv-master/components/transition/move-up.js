class Transition {
  constructor() {
    this.props = {
      'enter-active-class': 'move-up-enter move-up-enter-active',
      'leave-active-class': 'move-up-leave move-up-leave-active'
    }
  }
}

export default Transition

class Transition {
  constructor() {
    this.props = {
      'enter-active-class': 'zoom-big-fast-enter zoom-big-fast-enter-active',
      'leave-active-class': 'zoom-big-fast-leave zoom-big-fast-leave-active'
    }
  }
}

export default Transition

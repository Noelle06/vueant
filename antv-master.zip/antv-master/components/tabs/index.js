import './style/index.less'

import Tabs from './tabs'
import TabPane from './tab-pane'

Tabs.Pane = TabPane

export default Tabs

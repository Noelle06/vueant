import './style/index.less'

import Tag from './tag'

export default Tag

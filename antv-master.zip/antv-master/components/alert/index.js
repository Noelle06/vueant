import './style/index.less'

import Alert from './alert'

export default Alert

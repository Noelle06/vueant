import './style/index.less'

import Badge from './badge'

export default Badge

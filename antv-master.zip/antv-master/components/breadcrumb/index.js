import './style/index.less'

import Breadcrumb from './breadcrumb'
import BreadcrumbItem from './breadcrumb-item'

Breadcrumb.Item = BreadcrumbItem

export default Breadcrumb

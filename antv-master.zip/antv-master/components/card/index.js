import './style/index.less'

import Card from './card'

export default Card

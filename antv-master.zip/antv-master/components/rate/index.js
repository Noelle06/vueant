import './style/index.less'

import Rate from './rate'

export default Rate

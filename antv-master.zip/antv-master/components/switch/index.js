import './style/index.less'

import Switch from './switch'

export default Switch

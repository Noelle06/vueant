export default {
  MODE: {
    VERTICAL: 'vertical',
    HORIZONTAL: 'horizontal',
    INLINE: 'inline'
  }
}

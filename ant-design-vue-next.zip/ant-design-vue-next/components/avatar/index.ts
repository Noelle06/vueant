import Avatar from './Avatar';
import { withInstall } from '../_util/type';

export default withInstall(Avatar);

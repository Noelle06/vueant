import demoTest from '../../../tests/shared/demoTest';

demoTest('drawer');

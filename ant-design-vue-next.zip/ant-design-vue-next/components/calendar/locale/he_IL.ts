import he_IL from '../../date-picker/locale/he_IL';
export default he_IL;

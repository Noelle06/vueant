import ku_KU from '../../date-picker/locale/ku_KU';
export default ku_KU;

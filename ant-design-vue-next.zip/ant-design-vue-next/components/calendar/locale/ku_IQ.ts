import ku_IQ from '../../date-picker/locale/ku_IQ';
export default ku_IQ;

import ta_IN from '../../date-picker/locale/ta_IN';

export default ta_IN;

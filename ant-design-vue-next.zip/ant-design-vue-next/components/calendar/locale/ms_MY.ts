import ms_MY from '../../date-picker/locale/ms_MY';

export default ms_MY;

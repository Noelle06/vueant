import mk_MK from '../../date-picker/locale/mk_MK';

export default mk_MK;

import mn_MN from '../../date-picker/locale/mn_MN';
export default mn_MN;

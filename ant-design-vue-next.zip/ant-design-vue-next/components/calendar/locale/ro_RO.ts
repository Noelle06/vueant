import ro_RO from '../../date-picker/locale/ro_RO';

export default ro_RO;

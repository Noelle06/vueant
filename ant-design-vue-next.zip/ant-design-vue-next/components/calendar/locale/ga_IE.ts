import ga_IE from '../../date-picker/locale/ga_IE';

export default ga_IE;

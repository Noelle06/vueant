export default {
  'btn:save': '保存',
  'btn:cancel': '取消',
  'btn:clear': '清除',
};

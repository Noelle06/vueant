export default {
  'btn:save': 'پاشکەوت کردن',
  'btn:cancel': 'هەڵوەشاندنەوە',
  'btn:clear': 'پاککردنەوە',
};

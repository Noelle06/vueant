export default {
  'btn:save': 'Save',
  'btn:cancel': 'Cancel',
  'btn:clear': 'Clear',
};

import locale from '../locale/fr_FR';

export default locale;

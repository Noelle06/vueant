import locale from '../locale/fa_IR';

export default locale;

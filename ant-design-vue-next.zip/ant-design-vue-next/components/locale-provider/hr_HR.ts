import locale from '../locale/hr_HR';

export default locale;

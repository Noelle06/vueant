import demoTest from '../../../tests/shared/demoTest';

demoTest('anchor');

import '../../style/index.less';
import './index.less';

// style dependencies
import '../../empty/style';
import '../../spin/style';
import '../../pagination/style';
import '../../grid/style';

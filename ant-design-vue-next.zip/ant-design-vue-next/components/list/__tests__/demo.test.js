import demoTest from '../../../tests/shared/demoTest';

demoTest('list', { skip: ['infinite-virtualized-load', 'infinite-load', 'loadmore'] });

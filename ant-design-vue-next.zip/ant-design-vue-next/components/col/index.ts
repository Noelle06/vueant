import { Col } from '../grid';
import { withInstall } from '../_util/type';

export default withInstall(Col);

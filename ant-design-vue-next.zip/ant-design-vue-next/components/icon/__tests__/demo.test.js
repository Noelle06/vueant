import demoTest from '../../../tests/shared/demoTest';

demoTest('icon', { skip: ['custom.md'] });

const isValid = (value: any): boolean => {
  return value !== undefined && value !== null && value !== '';
};
export default isValid;

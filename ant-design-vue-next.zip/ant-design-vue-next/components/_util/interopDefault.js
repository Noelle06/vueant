// https://github.com/moment/moment/issues/3650
export default function interopDefault(m) {
  return m.default || m;
}

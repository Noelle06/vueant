<template>


		<div class="container page-content">
			<div class="row" >

				<div class=" col" >

					{{message}}

				</div>

			</div>
		</div>


</template>

<script>


export default {
	data() {
		return {
			message: 'Error 404',
		};
	}
};
</script>

export default {
  title: "DevExtreme App"
};

module.exports = {
  publicPath: "/devextreme-vue-template"
};

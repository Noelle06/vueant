Download model from [here](https://d2j0dndfm35trm.cloudfront.net/resnet-18.t7) and place it under this location

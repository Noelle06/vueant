python3 bin_2_ofrecord.py --data_dir=datasets/faces_emore --output_filepath=lfw/ --dataset_name="lfw"
python3 bin_2_ofrecord.py --data_dir=faces_emore --output_filepath=cfp_fp/ --dataset_name="cfp_fp"
python3 bin_2_ofrecord.py --data_dir=datasets/faces_emore --output_filepath=agedb_30/ --dataset_name="agedb_30"

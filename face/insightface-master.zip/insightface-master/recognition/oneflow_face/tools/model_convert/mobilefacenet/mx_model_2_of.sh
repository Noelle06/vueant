python mxnet_model_2_of_python.py --mxnet_load_prefix='mxnet_init_model/model' --mxnet_load_epoch=0 --of_model_dir='of_model/'

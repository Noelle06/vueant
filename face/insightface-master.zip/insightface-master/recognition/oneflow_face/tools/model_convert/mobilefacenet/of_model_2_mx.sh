python of_model_2_mxnet_model.py --mxnet_load_prefix='mxnet_load/model' --mxnet_load_epoch=0 --mxnet_save_prefix='mxnet_save/model' --mxnet_save_epoch=1 --of_model_dir='snapshot_10'

You can now find heatmap based approaches under ``heatmapReg`` directory.

You can now find coordinate regression approaches under ``coordinateReg`` directory.


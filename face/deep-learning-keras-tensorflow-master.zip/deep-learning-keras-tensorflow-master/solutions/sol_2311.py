y = w * x + b
loss = K.mean(K.square(y-target))
## Deprecated - Please Read

Due to TensorFlow radically changing their API in v2, the examples index have been split between [v1](../tensorflow_v1) and [v2](../tensorflow_v2).

The following examples are the original TF v1 examples, and will be deprecated entirely in favor of [tensorflow_v1](../tensorflow_v1) directory in a future release.
